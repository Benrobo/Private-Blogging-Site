<?php require('config/db.php'); 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Contact Page" />
    <title>Contact Page</title>
    <link rel="icon" href="img/Logo/LOGO.png" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
  </head>
  <body>
<!-- navbar contents -->
<?php require_once('includes/nav.php');?>

<!-- notfication-panel -->
<?php if(isset($_SESSION['userId']) && isset($_SESSION['adminRole']) && isset($_COOKIE['email']) && isset($_COOKIE['newpwd'])){ ?>
    <div class="notification-panel">
    <ul class="list-group mt-5">
        <!-- get all notification content -->
        <?php
        $stmt_not = mysqli_query($conn, "SELECT * FROM notification");
        if(mysqli_num_rows($stmt_not) > 0){
            // loop thoruh
        }
        else{
            echo "<li class='list-group-item'>Nothing to show</li>";
        }
        ?>
        <?php while($row = mysqli_fetch_assoc($stmt_not)){?>
        <li class="list-group-item list-not">
            <a href="posts.php?postid=<?php echo $row['postid']; ?>&title=<?php echo str_replace(" ","-", $row['post_title']) ?>" style="color:#000; text-decoration:none;" data-id="<?php echo $row['id']; ?>" class="notification-link">
            <?php if($row['user_role'] == "ADMIN"):?>
                <b>
                <?php echo "You ".$row['username']; ?>
                </b>
            <?php endif; ?>
            <?php if($row['user_role'] == "USER"):?>
                <b>
                <?php echo $row['username']; ?>
                </b>
            <?php endif;?>
            <span>Commented on your post.
            </span><span><small><?php echo $row['added_dt']; ?></small></span>
            </a>
        </li>
        <?php }?>
    </ul>
    </div>
<?php }?>

<header class="contact-header">
    <div class="overlay">
        <p><a href="index.php" class='text-white m-2'>← Back</a></p>
        <div class="ovl-cont">
            <h1 class='display-4 contacts-title'></h1>
            <br />
        </div>
    </div>

</header>

<section class="contact-section">
    <div class="contact-cont">
        <div class="main m-2">
            <div class="img m-2">
            </div>
        </div>
        <div class="contact-form m-2">
            <form action="contact_val.php" method="post" class="form-group">
                <h3>Contact Me</h3>
                <?php if(isset($_GET['msg'])){?>
                    <div class="alert alert-success m-1">
                        <small><?php echo $_GET['msg']; ?></small>
                    </div>
                <?php }else if(isset($_GET['_frmerr'])){?>
                    <div class="alert alert-danger m-1">
                        <small><?php echo $_GET['_frmerr']; ?></small>
                    </div>
                <?php } else if(isset($_GET['err'])){?>
                    <div class="alert alert-danger m-1">
                        <small><?php echo $_GET['err']; ?></small>
                    </div>
                <?php }?>
                <label for="name">Your Name</label>
                <input type="text" name="username" class="form-control m-1" required>
                <label for="name">Your Email</label>
                <input type="email" name="email" class="form-control m-1" required>
                <label for="name">Brief words</label>
                <textarea name="body" id="" cols="30" rows="6" class="form-control m-1 content"></textarea>

                <input type="submit" name="submit" value="Send Message" class="btn btn-info m-1 btn-block">
            </form>
        </div>
    </div>
</section>

<?php require("includes/footer.php");?>
