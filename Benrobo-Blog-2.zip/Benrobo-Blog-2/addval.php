<?php require('config/db.php'); ?>


<?php 

// redirect the user when they try coming to this page without clicking the submit button
if(isset($_POST['submit'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $subtitle =  mysqli_real_escape_string($conn, $_POST['sub_title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $body = mysqli_real_escape_string($conn, $_POST['body']);

    // validate user inputs
    if (empty($title) || empty($subtitle) || empty($author) || empty($body)) {
        header('location: addpost.php?err=fields cannot be empty');
        die();
    }
    if (is_numeric($title) || is_numeric($subtitle) || is_numeric($author)) {
        header('location: addpost.php?err=fields cannot be an integer');
        die();
    }

    else{
        $q = "INSERT INTO blog_info(title, sub_title, author, body) VALUE('$title','$subtitle','$author','$body')";
        if (mysqli_query($conn, $q)) {
            echo "success";
            header('location: index.php');
        }else{
            echo "error";
        }
    }
}else{
    header('location: index.php');
}


?>
