-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2021 at 09:22 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `benrobo-blog-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_bio`
--

CREATE TABLE `admin_bio` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `contents` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_bio`
--

INSERT INTO `admin_bio` (`id`, `userid`, `contents`) VALUES
(3, 2, '<p><strong>Benrobo-tuts</strong> is a blogging&nbsp;site purposely created for those intersted in any fields of technology, with tutorials and references on web development languages such as HTML, CSS, JavaScript, PHP, SQL, Python, jQuery,and Bootstrap, covering most aspects of web programming and in the aspect of Design Areas ranging from Graphic Design, UI/UX Designs.</p>\r\n\r\n<p><strong>Benrobo-tuts</strong> was created in 2021 by Alumona Benaiah, a&nbsp; software Developer.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `blog_post`
--

CREATE TABLE `blog_post` (
  `id` int(30) NOT NULL,
  `userid` int(30) NOT NULL,
  `position` text NOT NULL,
  `post_title` text NOT NULL,
  `post_author` text NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `post_media` text NOT NULL,
  `post_body` longtext NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog_post`
--

INSERT INTO `blog_post` (`id`, `userid`, `position`, `post_title`, `post_author`, `post_date`, `post_media`, `post_body`, `comments`) VALUES
(1, 2, 'admin', 'Making Money While Learning How To Code', 'benrobo', '2021-02-04 01:37:20', 'a (4).jpg', '<p>&lt;iframe width=&quot;949&quot; height=&quot;534&quot; src=&quot;https://www.youtube.com/embed/cNVKC3SMktU&quot; frameborder=&quot;0&quot; allow=&quot;accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture&quot; allowfullscreen&gt;&lt;/iframe&gt;</p>\r\n\r\n<p>Posts is been updating................</p>\r\n', '0'),
(2, 2, 'admin', 'JavaScript Array Methods', 'benrobo', '2021-01-30 17:32:35', '400090700343_284273.jpg', '<h2>JavaScript Array Methods</h2>\r\n\r\n<p>In this tutorial base, you will learn all you need to know in getting started with javascript array methods.</p>\r\n\r\n<hr />\r\n<h2>Converting Arrays to Strings</h2>\r\n\r\n<p>The JavaScript method&nbsp;<code>toString()</code>&nbsp;converts an array to a string of (comma separated) array values.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\ndocument.getElementById(&quot;demo&quot;).innerHTML = fruits.toString();\r\nResult:\r\nBanana,Orange,Apple,Mango</code>\r\n</pre>\r\n\r\n<p>The&nbsp;<code>join()</code>&nbsp;method also joins all array elements into a string.</p>\r\n\r\n<p>It behaves just like&nbsp;<code>toString()</code>, but in addition you can specify the separator:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\nvar fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\n<code>document.getElementById(&quot;demo&quot;).innerHTML = fruits.join(&quot; * &quot;);</code>\r\n<code>Result:</code>\r\n<code>Banana * Orange * Apple * Mango</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<hr />\r\n<h2>Popping and Pushing</h2>\r\n\r\n<p>When you work with arrays, it is easy to remove elements and add new elements.</p>\r\n\r\n<p>This is what popping and pushing is:</p>\r\n\r\n<p>Popping items&nbsp;<strong>out</strong>&nbsp;of an array, or pushing items&nbsp;<strong>into</strong>&nbsp;an array.</p>\r\n\r\n<hr />\r\n<h2>Popping</h2>\r\n\r\n<p>The&nbsp;<code>pop()</code>&nbsp;method removes the last element from an array:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.pop();              // Removes the last element (&quot;Mango&quot;) from fruits</code>\r\n</pre>\r\n\r\n<p>The&nbsp;<code>pop()</code>&nbsp;method returns the value that was &quot;popped out&quot;:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar x = fruits.pop();      // the value of x is &quot;Mango&quot;</code>\r\n</pre>\r\n\r\n<hr />\r\n<h2>Pushing</h2>\r\n\r\n<p>The&nbsp;<code>push()</code>&nbsp;method adds a new element to an array (at the end):</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.push(&quot;Kiwi&quot;);       //  Adds a new element (&quot;Kiwi&quot;) to fruits</code></pre>\r\n\r\n<p>The&nbsp;<code>push()</code>&nbsp;method returns the new array length:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar x = fruits.push(&quot;Kiwi&quot;);   //  the value of x is 5</code>\r\n</pre>\r\n\r\n<hr />\r\n<h2>Shifting Elements</h2>\r\n\r\n<p>Shifting is equivalent to popping, working on the first element instead of the last.</p>\r\n\r\n<p>The&nbsp;<code>shift()</code>&nbsp;method removes the first array element and &quot;shifts&quot; all other elements to a lower index.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.shift();            // Removes the first element &quot;Banana&quot; from fruits</code></pre>\r\n\r\n<p>The&nbsp;<code>shift()</code>&nbsp;method returns the string that was &quot;shifted out&quot;:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar x = fruits.shift();    // the value of x is &quot;Banana&quot;</code></pre>\r\n\r\n<p>The&nbsp;<code>unshift()</code>&nbsp;method adds a new element to an array (at the beginning), and &quot;unshifts&quot; older elements:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.unshift(&quot;Lemon&quot;);    // Adds a new element &quot;Lemon&quot; to fruits</code>\r\n</pre>\r\n\r\n<p>The&nbsp;<code>unshift()</code>&nbsp;method returns the new array length.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.unshift(&quot;Lemon&quot;);    // Returns 5</code></pre>\r\n\r\n<hr />\r\n<h2>Changing Elements</h2>\r\n\r\n<p>Array elements are accessed using their&nbsp;<strong>index number</strong>:</p>\r\n\r\n<p>Array&nbsp;<strong>indexes</strong>&nbsp;start with 0. [0] is the first array element, [1] is the second, [2] is the third ...</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits[0] = &quot;Kiwi&quot;;        // Changes the first element of fruits to &quot;Kiwi&quot;</code></pre>\r\n\r\n<p>The&nbsp;<code>length</code>&nbsp;property provides an easy way to append a new element to an array:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits[fruits.length] = &quot;Kiwi&quot;;          // Appends &quot;Kiwi&quot; to fruits</code></pre>\r\n\r\n<hr />\r\n<h2>Deleting Elements</h2>\r\n\r\n<p>Since JavaScript arrays are objects, elements can be deleted by using the JavaScript operator&nbsp;<code>delete</code>:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\ndelete fruits[0];           // Changes the first element in fruits to <strong>undefined</strong></code></pre>\r\n\r\n<p>Using&nbsp;<strong>delete</strong>&nbsp;may leave undefined holes in the array. Use pop() or shift() instead.</p>\r\n\r\n<hr />\r\n<h2>Splicing an Array</h2>\r\n\r\n<p>The&nbsp;<code>splice()</code>&nbsp;method can be used to add new items to an array:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.splice(2, 0, &quot;Lemon&quot;, &quot;Kiwi&quot;);</code></pre>\r\n\r\n<p>The first parameter (2) defines the position&nbsp;<strong>where</strong>&nbsp;new elements should be&nbsp;<strong>added</strong>&nbsp;(spliced in).</p>\r\n\r\n<p>The second parameter (0) defines&nbsp;<strong>how many</strong>&nbsp;elements should be&nbsp;<strong>removed</strong>.</p>\r\n\r\n<p>The rest of the parameters (&quot;Lemon&quot; , &quot;Kiwi&quot;) define the new elements to be&nbsp;<strong>added</strong>.</p>\r\n\r\n<p>The&nbsp;<code>splice()</code>&nbsp;method returns an array with the deleted items:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.splice(2, 2, &quot;Lemon&quot;, &quot;Kiwi&quot;);</code></pre>\r\n\r\n<hr />\r\n<h2>Using splice() to Remove Elements</h2>\r\n\r\n<p>With clever parameter setting, you can use&nbsp;<code>splice()</code>&nbsp;to remove elements without leaving &quot;holes&quot; in the array:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nfruits.splice(0, 1);        // Removes the first element of fruits</code></pre>\r\n\r\n<p>The first parameter (0) defines the position where new elements should be&nbsp;<strong>added</strong>&nbsp;(spliced in).</p>\r\n\r\n<p>The second parameter (1) defines&nbsp;<strong>how many</strong>&nbsp;elements should be&nbsp;<strong>removed</strong>.</p>\r\n\r\n<p>The rest of the parameters are omitted. No new elements will be added.</p>\r\n\r\n<hr />\r\n<h2>Merging (Concatenating) Arrays</h2>\r\n\r\n<p>The&nbsp;<code>concat()</code>&nbsp;method creates a new array by merging (concatenating) existing arrays:</p>\r\n\r\n<h3>Example (Merging Two Arrays)</h3>\r\n\r\n<pre>\r\n<code>var myGirls = [&quot;Cecilie&quot;, &quot;Lone&quot;];\r\nvar myBoys = [&quot;Emil&quot;, &quot;Tobias&quot;, &quot;Linus&quot;];\r\nvar myChildren = myGirls.concat(myBoys);   // Concatenates (joins) myGirls and myBoys</code></pre>\r\n\r\n<p>The&nbsp;<code>concat()</code>&nbsp;method does not change the existing arrays. It always returns a new array.</p>\r\n\r\n<p>The&nbsp;<code>concat()</code>&nbsp;method can take any number of array arguments:</p>\r\n\r\n<h3>Example (Merging Three Arrays)</h3>\r\n\r\n<pre>\r\n<code>var arr1 = [&quot;Cecilie&quot;, &quot;Lone&quot;];\r\nvar arr2 = [&quot;Emil&quot;, &quot;Tobias&quot;, &quot;Linus&quot;];\r\nvar arr3 = [&quot;Robin&quot;, &quot;Morgan&quot;];\r\nvar myChildren = arr1.concat(arr2, arr3);   // Concatenates arr1 with arr2 and arr3</code></pre>\r\n\r\n<p>The&nbsp;<code>concat()</code>&nbsp;method can also take values as arguments:</p>\r\n\r\n<h3>Example (Merging an Array with Values)</h3>\r\n\r\n<pre>\r\n<code>var arr1 = [&quot;Cecilie&quot;, &quot;Lone&quot;];\r\nvar myChildren = arr1.concat([&quot;Emil&quot;, &quot;Tobias&quot;, &quot;Linus&quot;]); </code></pre>\r\n\r\n<hr />\r\n<h2>Slicing an Array</h2>\r\n\r\n<p>The&nbsp;<code>slice()</code>&nbsp;method slices out a piece of an array into a new array.</p>\r\n\r\n<p>This example slices out a part of an array starting from array element 1 (&quot;Orange&quot;):</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Lemon&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar citrus = fruits.slice(1);</code></pre>\r\n\r\n<p>The&nbsp;<code>slice()</code>&nbsp;method creates a new array. It does not remove any elements from the source array.</p>\r\n\r\n<p>This example slices out a part of an array starting from array element 3 (&quot;Apple&quot;):</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Lemon&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar citrus = fruits.slice(3);</code></pre>\r\n\r\n<p>The&nbsp;<code>slice()</code>&nbsp;method can take two arguments like&nbsp;<code>slice(1, 3)</code>.</p>\r\n\r\n<p>The method then selects elements from the start argument, and up to (but not including) the end argument.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Lemon&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar citrus = fruits.slice(1, 3);</code></pre>\r\n\r\n<p>If the end argument is omitted, like in the first examples, the&nbsp;<code>slice()</code>&nbsp;method slices out the rest of the array.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Lemon&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\nvar citrus = fruits.slice(2);</code></pre>\r\n\r\n<hr />\r\n<h2>Automatic toString()</h2>\r\n\r\n<p>JavaScript automatically converts an array to a comma separated string when a primitive value is expected.</p>\r\n\r\n<p>This is always the case when you try to output an array.</p>\r\n\r\n<p>These two examples will produce the same result:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\ndocument.getElementById(&quot;demo&quot;).innerHTML = fruits.toString();</code>\r\n</pre>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>var fruits = [&quot;Banana&quot;, &quot;Orange&quot;, &quot;Apple&quot;, &quot;Mango&quot;];\r\ndocument.getElementById(&quot;demo&quot;).innerHTML = fruits;</code></pre>\r\n', '0'),
(3, 2, 'admin', 'JavaScript Functions', 'benrobo', '2021-01-30 18:23:16', '400082100376_285832.jpg', '<h3>JavaScript Functions</h3>\r\n\r\n<p>A JavaScript function is a block of code designed to perform a particular task.</p>\r\n\r\n<p>A JavaScript function is executed when &quot;something&quot; invokes it (calls it).</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<pre>\r\n<code>function myFunction(p1, p2) {\r\n  return p1 * p2;   // The function returns the product of p1 and p2\r\n}</code></pre>\r\n\r\n<h3>JavaScript Function Syntax</h3>\r\n\r\n<p>A JavaScript function is defined with the&nbsp;<code>function</code>&nbsp;keyword, followed by a&nbsp;<strong>name</strong>, followed by parentheses&nbsp;<strong>()</strong>.</p>\r\n\r\n<p>Function names can contain letters, digits, underscores, and dollar signs (same rules as variables).</p>\r\n\r\n<p>The parentheses may include parameter names separated by commas:<br />\r\n<strong>(<em>parameter1, parameter2, ...</em>)</strong></p>\r\n\r\n<p>The code to be executed, by the function, is placed inside curly brackets:&nbsp;<strong>{}</strong></p>\r\n\r\n<pre>\r\n<code>function <em>name</em>(<em>parameter1, parameter2, parameter3</em>) {\r\n  // <em>code to be executed</em>\r\n}</code></pre>\r\n\r\n<h3>Function Return</h3>\r\n\r\n<p>When JavaScript reaches a&nbsp;<code>return</code>&nbsp;statement, the function will stop executing.</p>\r\n\r\n<p>If the function was invoked from a statement, JavaScript will &quot;return&quot; to execute the code after the invoking statement.</p>\r\n\r\n<p>Functions often compute a&nbsp;<strong>return value</strong>. The return value is &quot;returned&quot; back to the &quot;caller&quot;:</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<p>Calculate the product of two numbers, and return the result:</p>\r\n\r\n<pre>\r\n<code>var x = myFunction(4, 3);   // Function is called, return value will end up in x\r\n\r\nfunction myFunction(a, b) {\r\n  return a * b;             // Function returns the product of a and b\r\n}</code></pre>\r\n\r\n<p>The result in x will be:</p>\r\n\r\n<p><code>12</code></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3>Why Functions?</h3>\r\n\r\n<p>You can reuse code: Define the code once, and use it many times.</p>\r\n\r\n<p>You can use the same code many times with different arguments, to produce different results.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<p>Convert Fahrenheit to Celsius:</p>\r\n\r\n<pre>\r\n<code>function toCelsius(fahrenheit) {\r\n  return (5/9) * (fahrenheit-32);\r\n}\r\ndocument.getElementById(&quot;demo&quot;).innerHTML = toCelsius(77);</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3>Functions Used as Variable Values</h3>\r\n\r\n<p>Functions can be used the same way as you use variables, in all types of formulas, assignments, and calculations.</p>\r\n\r\n<h3>Example</h3>\r\n\r\n<p>Instead of using a variable to store the return value of a function:</p>\r\n\r\n<pre>\r\n<code>var x = toCelsius(77);\r\nvar text = &quot;The temperature is &quot; + x + &quot; Celsius&quot;;</code></pre>\r\n\r\n<p>You can use the function directly, as a variable value:</p>\r\n\r\n<pre>\r\n<code>var text = &quot;The temperature is &quot; + toCelsius(77) + &quot; Celsius&quot;;</code></pre>\r\n\r\n<p>And that it guys, thanks for reading through.🥰🥰</p>\r\n', '0'),
(4, 2, 'admin', 'File uploads In PHP', 'benrobo', '2021-02-01 10:58:41', 'a (14).jpg', '<pre>\r\n<code class=\"language-php\">&lt;?php\r\n$target_dir = \"uploads/\";\r\n$target_file = $target_dir . basename($_FILES[\"fileToUpload\"][\"name\"]);\r\n$uploadOk = 1;\r\n$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));\r\n// Check if image file is a actual image or fake image\r\nif(isset($_POST[\"submit\"])) {\r\n    $check = getimagesize($_FILES[\"fileToUpload\"][\"tmp_name\"]);\r\n    if($check !== false) {\r\n        echo \"File is an image - \" . $check[\"mime\"] . \".\";\r\n        $uploadOk = 1;\r\n    } else {\r\n        echo \"File is not an image.\";\r\n        $uploadOk = 0;\r\n    }\r\n}\r\n// Check if file already exists\r\nif (file_exists($target_file)) {\r\n    echo \"Sorry, file already exists.\";\r\n    $uploadOk = 0;\r\n}\r\n// Check file size\r\nif ($_FILES[\"fileToUpload\"][\"size\"] &gt; 500000) {\r\n    echo \"Sorry, your file is too large.\";\r\n    $uploadOk = 0;\r\n}\r\n// Allow certain file formats\r\nif($imageFileType != \"jpg\" &amp;&amp; $imageFileType != \"png\" &amp;&amp; $imageFileType != \"jpeg\"\r\n&amp;&amp; $imageFileType != \"gif\" ) {\r\n    echo \"Sorry, only JPG, JPEG, PNG &amp; GIF files are allowed.\";\r\n    $uploadOk = 0;\r\n}\r\n// Check if $uploadOk is set to 0 by an error\r\nif ($uploadOk == 0) {\r\n    echo \"Sorry, your file was not uploaded.\";\r\n// if everything is ok, try to upload file\r\n} else {\r\n    if (move_uploaded_file($_FILES[\"fileToUpload\"][\"tmp_name\"], $target_file)) {\r\n        echo \"The file \". basename( $_FILES[\"fileToUpload\"][\"name\"]). \" has been uploaded.\";\r\n    } else {\r\n        echo \"Sorry, there was an error uploading your file.\";\r\n    }\r\n}\r\n?&gt;</code></pre>\r\n\r\n<p>File uploads In PHP</p>\r\n', '0'),
(7, 2, 'admin', 'Sending Mails With PHP.', 'benrobo', '2021-02-01 10:23:00', 'email.jpeg', '<pre>\r\n<code class=\"language-php\">&lt;?php \r\n    if(isset($_GET[\'msg\'])){\r\n        $msg = $_GET[\'msg\'];\r\n        echo \"&lt;div style=\'border-radius:0px;\' class=\'alert alert-success alert-error\'&gt;\".$msg.\"&lt;/div&gt;\";\r\n        header(\"Refresh: 1, admin.php\");\r\n    }\r\n    elseif(isset($_GET[\'err\'])){\r\n        $err = $_GET[\'err\'];\r\n        echo \"&lt;div style=\'border-radius:0px;\' class=\'alert alert-danger alert-error\'&gt;\".$err.\"&lt;/div&gt;\";\r\n        header(\"Refresh: 1, admin.php\");\r\n    }\r\n        else{\r\n        echo \"\";\r\n    } \r\n?&gt;</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n', ''),
(8, 2, 'admin', 'Differences Between Angular.js and React.js', 'benrobo', '2021-02-05 07:28:30', 'a (34).jpg', '<h2><strong>Differences Between Angular.js&nbsp;&amp; React.js</strong></h2>\r\n\r\n<p>If you&#39;ve ever wonder the differences between&nbsp;<em>Reactjs and Angular.js&nbsp;</em>and which oxne to pick for your next frontend framework to begin with, your in the right place. In this article i be gouing through this two languages and the diffrences between them. kk let dive in.</p>\r\n\r\n<p><strong>✅ Front End Developer.</strong></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp;&nbsp;<strong>1. React.js</strong></p>\r\n\r\n<p><strong><img alt=\"React.js\" src=\"ckeditor/uploads/a (81).jpg\" style=\"height:338px; width:600px\" /></strong></p>\r\n\r\n<p>React is a JavaScript library for building user interfaces. React is used to build single page applications. React allows us to create reusable UI components. Believe it or not, React is one of the outstanding tech outthere in market place.</p>\r\n\r\n<p>To use React in production, you need NPM and Node.js</p>\r\n\r\n<p>To get an overview of what React is, you can write React code directly in HTML.</p>\r\n\r\n<p>But in order to use React in production, you need NPM and Node.js installed.</p>\r\n\r\n<h2>React Directly in HTML</h2>\r\n\r\n<p>The quickest way start learning React is to write React directly in your HTML files.</p>\r\n\r\n<p>Start by including three scripts, the first two let us write React code in our JavaScripts, and the third, Babel, allows us to write JSX syntax and ES6 in older browsers.</p>\r\n\r\n<p>React Code Example.</p>\r\n\r\n<pre>\r\n<code class=\"language-coffeescript\">import React from \"react\";\r\nimport ReactDOM from \"react-dom\";\r\n\r\nclass Test extends React.Component {\r\n  render() {\r\n    return(\"&lt;h1&gt;Hello world&lt;/h1&gt;\");\r\n} </code></pre>\r\n\r\n<p>Include three CDN&#39;s in your HTML file:</p>\r\n\r\n<pre>\r\n<code class=\"language-javascript\">&lt;!DOCTYPE html&gt;\r\n&lt;html&gt;\r\n  &lt;script src=\"https://unpkg.com/react@16/umd/react.production.min.js\"&gt;&lt;/script&gt;\r\n  &lt;script src=\"https://unpkg.com/react-dom@16/umd/react-dom.production.min.js\"&gt;&lt;/script&gt;\r\n  &lt;script src=\"https://unpkg.com/babel-standalone@6.15.0/babel.min.js\"&gt;&lt;/script&gt;\r\n  &lt;body&gt;\r\n  \r\n    &lt;div id=\"mydiv\"&gt;&lt;/div&gt;\r\n\r\n    &lt;script type=\"text/babel\"&gt;\r\n      class Hello extends React.Component {\r\n        render() {\r\n          return &lt;h1&gt;Hello World!&lt;/h1&gt;\r\n        }\r\n      }\r\n\r\n      ReactDOM.render(&lt;Hello /&gt;, document.getElementById(\'mydiv\'))\r\n    &lt;/script&gt;\r\n  &lt;/body&gt;\r\n&lt;/html&gt;</code></pre>\r\n\r\n<p><strong>2. Angular.js</strong></p>\r\n\r\n<p><strong><img alt=\"Angular.js\" src=\"ckeditor/uploads/a (31).jpg\" style=\"height:225px; width:400px\" /></strong></p>\r\n\r\n<p>AngularJS is a&nbsp;<strong>JavaScript framework</strong>. It can be added to an HTML page with a</p>\r\n\r\n<p>AngularJS is a&nbsp;<strong>JavaScript framework</strong>. It can be added to an HTML page with a &lt;script&gt; tag.</p>\r\n\r\n<p>AngularJS extends HTML attributes with&nbsp;<strong>Directives</strong>, and binds data to HTML with&nbsp;<strong>Expressions</strong>.</p>\r\n\r\n<h2>AngularJS is a JavaScript Framework</h2>\r\n\r\n<p>AngularJS is a JavaScript framework written in JavaScript.</p>\r\n\r\n<p>AngularJS is distributed as a JavaScript file, and can be added to a web page with a script tag:</p>\r\n\r\n<pre>\r\n<code class=\"language-html\">&lt;script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js\"&gt;&lt;/script&gt;</code></pre>\r\n\r\n<h2>AngularJS Extends HTML</h2>\r\n\r\n<p>AngularJS extends HTML with&nbsp;<strong>ng-directives</strong>. The&nbsp;<strong>ng-app</strong>&nbsp;directive defines an AngularJS application. The&nbsp;<strong>ng-model</strong>&nbsp;directive binds the value of HTML controls (input, select, textarea) to application data.</p>\r\n\r\n<p>The&nbsp;<strong>ng-bind</strong>&nbsp;directive binds application data to the HTML view.</p>\r\n\r\n<pre>\r\n<code class=\"language-html\">&lt;!DOCTYPE html&gt;\r\n&lt;html&gt;\r\n&lt;script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js\"&gt;&lt;/script&gt;\r\n&lt;body&gt;\r\n\r\n&lt;div ng-app=\"\"&gt;\r\n  &lt;p&gt;Name: &lt;input type=\"text\" ng-model=\"name\"&gt;&lt;/p&gt;\r\n  &lt;p&gt;{{name}}&lt;/p&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;/body&gt;\r\n&lt;/html&gt;</code></pre>\r\n\r\n<h2>AngularJS Applications</h2>\r\n\r\n<p>AngularJS&nbsp;<strong>modules</strong>&nbsp;define AngularJS applications.</p>\r\n\r\n<p>AngularJS&nbsp;<strong>controllers</strong>&nbsp;control AngularJS applications.</p>\r\n\r\n<p>The&nbsp;<strong>ng-app</strong>&nbsp;directive defines the application, the&nbsp;<strong>ng-controller</strong>&nbsp;directive defines the controller.</p>\r\n\r\n<pre>\r\n<code class=\"language-html\">&lt;div ng-app=\"myApp\" ng-controller=\"myCtrl\"&gt;\r\n\r\nFirst Name: &lt;input type=\"text\" ng-model=\"firstName\"&gt;&lt;br&gt;\r\nLast Name: &lt;input type=\"text\" ng-model=\"lastName\"&gt;&lt;br&gt;\r\n&lt;br&gt;\r\nFull Name: {{firstName + \" \" + lastName}}\r\n\r\n&lt;/div&gt;\r\n\r\n&lt;script&gt;\r\nvar app = angular.module(\'myApp\', []);\r\napp.controller(\'myCtrl\', function($scope) {\r\n  $scope.firstName= \"John\";\r\n  $scope.lastName= \"Doe\";\r\n});\r\n&lt;/script&gt;</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>ok guys, that it hope you enjoy it and getting your sleves ready to start learning AngularJs &amp; Reactjs. If you enjoy it, pls leave a comment bellow the section, for further enquires pls use the contact form to give us your feedback.✅✅😍😍</p>\r\n', '');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `post_title` text NOT NULL,
  `comments` text NOT NULL,
  `comm_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_tbl`
--

CREATE TABLE `newsletter_tbl` (
  `id` int(30) NOT NULL,
  `username` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `suscribe_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newsletter_tbl`
--

INSERT INTO `newsletter_tbl` (`id`, `username`, `email`, `suscribe_at`) VALUES
(8, 'kwickquick', 'kwickquick71@gmail.com', '2021-01-28 22:53:47'),
(11, 'benrobo', 'kwicklink@mail.com', '2021-01-28 23:59:10'),
(12, 'brad', 'brad@mail.com', '2021-01-29 00:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(30) NOT NULL,
  `userid` int(11) NOT NULL,
  `user_role` text NOT NULL,
  `username` text NOT NULL,
  `postid` int(11) NOT NULL,
  `post_title` text NOT NULL,
  `added_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_auth`
--

CREATE TABLE `user_auth` (
  `id` int(30) NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `pwd_hash` varchar(255) NOT NULL,
  `isLogged_in` int(30) NOT NULL,
  `position` text NOT NULL,
  `profile_pic` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_auth`
--

INSERT INTO `user_auth` (`id`, `username`, `email`, `pwd_hash`, `isLogged_in`, `position`, `profile_pic`) VALUES
(2, 'benrobo', 'alumonabenaiah71@gmail.com', '$2y$10$B9Bbkkz3ZwvVYPZ3b12Wh.ruaSwC/Ub3uyej2RoZ745bNL2aRIdQS', 1, 'ADMIN', 'Web capture_23-1-2021_111936_.jpeg'),
(3, 'kwickquick', 'kwickquick@gmail.com', '$2y$10$wNtLY2eyrL3ceDyw6V3WseHJKbUc4x2ThEURR6OB2vUcobutR1eu2', 0, 'USER', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_bio`
--
ALTER TABLE `admin_bio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_post`
--
ALTER TABLE `blog_post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `newsletter_tbl`
--
ALTER TABLE `newsletter_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_auth`
--
ALTER TABLE `user_auth`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_bio`
--
ALTER TABLE `admin_bio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `blog_post`
--
ALTER TABLE `blog_post`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newsletter_tbl`
--
ALTER TABLE `newsletter_tbl`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_auth`
--
ALTER TABLE `user_auth`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user_auth` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
