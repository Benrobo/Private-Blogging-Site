<?php require_once('includes/head.php');?>
<?php require('config/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="PostPage | Comments Edit?>" />
    <title>Edit Comment</title>
    <link rel="icon" href="img/Logo/LOGO.png" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <style>
        .edit-cont{
            width:100%;
            height:100vh;
            position:absolute;
            top:0px;
            left:0px;
            background:rgba(0,0,0,.9);
            display:flex;
            align-content:center;
            justify-content:center;
            flex-direction:column;
            color:#fff;
        }
        .form-cont{
            width:600px;
            text-align:start;
            margin:0px auto;
        }
        .navbar{
            z-index:5;
            background:#000;
            color:#fff;

        }
        .alert{
            z-index:5;
        }
        form{
            width:550px;
            margin:0px auto;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <button onclick="goBack()" class="btn btn-info">Go Back</button>
    <h5>Edit Comment</h5>
</nav>
<?php 
session_start();


if(isset($_GET['postid']) && isset($_GET['userid']) && isset($_GET['cmtid'])){
    $pstid = $_GET['postid'];
    $sql_query = mysqli_query($conn, "SELECT * FROM blog_post WHERE id='$pstid'");
    $oup = mysqli_fetch_assoc($sql_query);

    #get comment value from comments table when comment id and postid are set
    
    $cmtid = $_GET['cmtid']; 
    $postid = $_GET['postid'];
    $userid = $_GET['userid'];
    $stmt = mysqli_query($conn, "SELECT * FROM comments WHERE postid='$postid' AND userid='$userid' AND id='$cmtid'");
    $result = mysqli_fetch_assoc($stmt);

    #run the following codes bellow only when the submit button is clicked

    if(isset($_POST['submit'])){
        $postid = $_GET['postid'];
        $userid = $_GET['userid'];
        $cmtid = $_GET['cmtid'];
        $comment = mysqli_real_escape_string($conn, htmlspecialchars($_POST['comment']));
        if(empty($comment)){
            echo '<div class="alert alert-success">Fields cannot be empty</div>';  
        }else{
            #update comment where userid == userid
            $comm_query = mysqli_query($conn, "UPDATE comments SET comments ='$comment' WHERE postid='$postid' AND userid='$userid' AND id='$cmtid'"); 

            if($comm_query){
                echo '<div class="alert alert-success">Comment Updated</div>'; 
                
            }else{
                echo '<div class="alert alert-success">An error occur while updating comment'.mysqli_error($conn).'</div>';
            } 
            
        }  
    }// $fakeid = $_GET['userid'];
    else if($_GET['userid'] != $_SESSION['userId'] || mysqli_num_rows($sql_query) == 0){
        header("location: dashboard/error.php?err=Sorry cannot get the page you are looking for");
        die;
    }
}

else{
    header("location: index.php");
    die;
}

?>
<div class="edit-cont">
    <div class="form-cont">
        <form method="post" class="form-group">
            <textarea name="comment" id="body" cols="30" rows="7" class="form-control m-1"><?php echo $result['comments'];?></textarea>

            <input type="submit" id="comment-btn" name="submit" value="Save" class="btn btn-block btn-info m-1">
        </form>
    </div>
</div>


<script>
function goBack() {
  window.history.back();
}
let alert = document.querySelector(".alert");
setTimeout(() => {
    alert.style.display = "none";
}, 2000);
</script>

