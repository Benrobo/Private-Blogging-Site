<?php require_once('includes/head.php');?>
<?php require('config/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="PostPage | Comments Edit?>" />
    <title>Edit Comment</title>
    <link rel="icon" href="img/Logo/LOGO.png" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <style>
        
        .navbar{
            z-index:5;
            background:#000;
            color:#fff;

        }
        .alert{
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%, -50%);
            z-index:5;
            margin:100px auto;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <button onclick="goBack()" class="btn btn-info">Go Back</button>
    <h5>Delete Comment</h5>
</nav>
<?php 
session_start();


if(isset($_GET['postid']) && isset($_GET['userid']) && isset($_GET['cmtid'])){
    $pstid = $_GET['postid'];
    $sql_query = mysqli_query($conn, "SELECT * FROM blog_post WHERE id='$pstid'");
    $oup = mysqli_fetch_assoc($sql_query);

    $postid = $_GET['postid'];
    $userid = $_GET['userid'];
    $cmtid = $_GET['cmtid'];
    #update comment where userid == userid
    $comm_query = mysqli_query($conn, "DELETE FROM comments WHERE postid='$postid' AND userid='$userid' AND id='$cmtid'"); 

    if($_GET['userid'] != $_SESSION['userId'] || mysqli_num_rows($sql_query) == 0){
        header("location: dashboard/error.php?err=Sorry cannot get the page you are looking for");
        die;
    }
    else if($comm_query){
        echo '<div class="alert alert-success">Comment Deleted</div>'; 
        
    }
    
    else{
        echo '<div class="alert alert-success">An error occur while Deleting comment'.mysqli_error($conn).'</div>';
    } 
    
}
else{
    header("location: index.php");
    die;
}

?>
<script>
function goBack() {
  window.history.back();
}
let alert = document.querySelector(".alert");
setTimeout(() => {
    alert.style.display = "none";
}, 2000);
</script>

