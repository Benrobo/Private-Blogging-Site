<?php 

// check if we are connected to the db
$path = $_SERVER['SERVER_NAME'].":".$_SERVER['PHP_SELF'];
$host = $_SERVER['SERVER_NAME'];
$root = "root";
$pwd = null; 
$db = "benrobo-blog-2";

// check
$conn = mysqli_connect($host, $root, $pwd, $db);

// if we are connected a success message is shown else an error message is shown

// if ($conn) {
//     echo "Successfully connected to your database";
// }else{
//     echo "an arror occur".mysqli_error($conn);
// }


?>