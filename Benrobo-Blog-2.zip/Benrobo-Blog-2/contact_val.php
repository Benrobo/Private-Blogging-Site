<?php 
require("config/db.php");

if(isset($_POST['submit'])){

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $msg = mysqli_real_escape_string($conn, $_POST['body']);

    #validate inputs
    if(empty($username) || empty($email) || empty($msg)){
        header("location: contact.php?_frmerr=Fields cannot be empty");
        die;
    }
    else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        header("location: contact.php?_frmerr=Email given is invalid");
        die;
    }
    else{
        #send me mail
        $from = "From: ".$email;
        $to = "kwickquick71@gmail.com";
        $subject = "Contact Form Request: ".$username;
        $body = "From: ".$email."\r\n";
        $body .= $msg;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <benrobo-tuts.com>' . "\r\n";
        $headers .= 'Cc: kwickquick71@gmail.com' . "\r\n";

        if(mail($to, $subject, $body,$headers)){
            header("location: contact.php?msg=Thanks for viewing benrobo-tuts, your message has been sent. i get back to you as soon as possible");
            die;
        }else{
            header("location: contact.php?err=Sorry an error occur while sending message, pls try later");
            die;
        }

    }

}
else{
    header("location: index.php");
    die;
}



?>