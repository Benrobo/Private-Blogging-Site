/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'ug', {
	pathName: 'ۋاسىتە ئوبيېكتى',
	title: 'سىڭدۈرمە ۋاسىتە',
	button: 'سىڭدۈرمە ۋاسىتە قىستۇر',
	unsupportedUrlGiven: 'بەلگىلەنگەن ئۇلانمىنى قوللىمايدۇ .',
	unsupportedUrl: 'The URL {url} is not supported by Media Embed.', // MISSING
	fetchingFailedGiven: 'Failed to fetch content for the given URL.', // MISSING
	fetchingFailed: 'Failed to fetch content for {url}.', // MISSING
	fetchingOne: 'oEmbed نىڭ ئىنكاسىغا ئېرىشىۋاتىدۇ ...',
	fetchingMany: 'Fetching oEmbed responses, {current} of {max} done...' // MISSING
} );
