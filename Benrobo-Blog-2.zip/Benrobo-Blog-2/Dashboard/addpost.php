<?php 
require("../config/db.php");

session_start();

if(isset($_POST['postsubmit'])){
  # check is session is set eitheir by admin or user

  if(isset($_SESSION['adminRole']) || isset($_SESSION['userId'])){

    # uploads functionality
    $title = htmlspecialchars($_POST['postTitle']);
    $author = $_POST['author'];
    $body = mysqli_real_escape_string($conn, $_POST['body']); 
    $uploadOk = 1;
    // echo $body;die;
    #Validate inputs
    if(empty($title) || empty($body)){
      $err = "Fields cannot be empty";
      if(isset($_SESSION['adminRole'])){
        header("location: postform.php?err=$err");
        die;
      }
    }else{
      # file uploads
      $dir = "../uploads/";

      $file = $dir . basename($_FILES['fileupload']['name']);
      $fileType = strtolower(pathinfo($file,PATHINFO_EXTENSION));

      # Check if image file is a actual image or fake image
      $check = getimagesize($_FILES["fileupload"]["tmp_name"]);
      if($check !== false) {
        $uploadOk = 1;
      } else {
        echo "File is not an image.";
        $uploadOk = 0;
      }
      # check file size
      if ($_FILES["fileupload"]["size"] > 5000000) {
        $err = "File too large cant upload";
        if(isset($_SESSION['adminRole'])){
        header("location: postform.php?err=$err");
        die;
        }else{
          die();
        }
        $uploadOk = 0;
      }

        # Allow certain file formats
      if($fileType != "jpg" && $fileType != "png" && $fileType != "jpeg"
      && $fileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
      }


      # Check if $uploadOk is set to 0 by an error
      if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
      # if everything is ok, try to upload file
      } else {
        if (move_uploaded_file($_FILES["fileupload"]["tmp_name"], $file)) {
          # send image and all inputs to db

          $newfiletype = $_FILES['fileupload']['name'];
          
          #check if post title is already taken
          $stmt = "SELECT * FROM blog_post WHERE post_title='$title'";
          $query = mysqli_query($conn, $stmt);
          if(mysqli_num_rows($query) > 0){
            $err = "Post with that Title is already taken, try using a different title";
            if(isset($_SESSION['adminRole'])){
              header("location: postform.php?err=$err");
              die;
            }
          }else{
            #SQL STATEMENT TO INSERT RECORDS INTO DB

            if(isset($_SESSION["userId"]) && isset($_SESSION['adminRole'])){
                $adminid = $_SESSION['userId'];
                $adminrole = $_SESSION['adminRole'];
                $stmt = "INSERT INTO blog_post (userid,position,post_title,post_author, post_media, post_body)
              VALUES('$adminid','$adminrole','$title','$author','$newfiletype','$body')";
              $query = mysqli_query($conn, $stmt);
              if($query){
                $msg = "Successfully uploaded your post";
                header("location: postform.php?msg=Successfully uploaded your post");
                die;
              }else{
                $err = "Theres was an error while uploading item please retry later".mysqli_error($conn);
                echo $err;
                // header("location: postform.php?err=Theres was an error while uploading item please retry later");
                die;
              }
            }else{
              $err = "Theres was an error while uploading item, please retry later";
              if(isset($_SESSION['adminRole'])){
                header("location: postform.php?err=$err");
                die;
              }
            }
          }
          
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
      }
    }
  }
}
else{
  header("location: ../index.php");
}

?>