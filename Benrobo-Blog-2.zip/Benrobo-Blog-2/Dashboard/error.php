<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta  name="404 Page" description="Error 404 Page">
    <title>Error 404</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        .error-cont{
            text-align:center;
            line-height:30px;
            height:150px;
            position:absolute;
            top:30%;
            left:50%;
            transform:translate(-50%, -30%);
        }
        .error-text{
            color:cyan;
            text-align:center;
            
        }
        .error{
            animation:glow .5s ease-in-out infinite alternate;
            transition:1s;
            color:#fff;
            font-family:Verdana;
        }
        /* @keyframes glow{
            0%{
                text-shadow:-3px -3px 10px #00ffff, -3px -3px 10px #00ffff;
            }
            100%{
                text-shadow:-3px -3px 15px #00ffff, -3px -3px 20px #00ffff;
            }
        } */
        @keyframes glow{
            0%{
                 text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px cyan, 0 0 40px cyan, 0 0 50px cyan, 0 0 60px cyan, 0 0 70px cyan;
            }
            100%{
                text-shadow: 0 0 20px #fff, 0 0 30px cyan, 0 0 40px cyan, 0 0 50px cyan, 0 0 60px cyan, 0 0 70px cyan, 0 0 80px cyan;
            }
        }
        .btn-primary{
            background:cyan;
            border-radius:30px;
            outline:cyan;
            border:3px solid cyan;
            padding:12px;
            color:#000;
            font-family:verdana;
            box-shadow:0px 0px 5px cyan, 0px 0px 10px cyan;
        }
        body{
            background:#000;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-cont">
            <h1 class="display-1 error">404 ERROR</h1>
            <br>
            <h5 class="error-text">
                <?php 
                session_start();
                if(isset($_GET['err'])){
                    if(isset($_SESSION['adminRole']) || isset($_SESSION['userRole'])){
                        echo $_GET['err'];
                    }
                }else{
                    echo "";
                    header("location: ../index.php");
                }

                ?>
            </h5>
            <br>
            <br>
            <a href="../index.php" class="">
                    <button class="btn btn-primary p-2">Return to Homepage</button>
            </a>
        </div>
    </div>
</body>
</html>