<?php 
require("../config/db.php");

session_start();

# check if user or admin is logged in before accessing this page
if(isset($_SESSION['adminRole']) && isset($_SESSION['userId']) && isset($_COOKIE['email']) && isset($_COOKIE['newpwd'])){
    #check if user has clicked the link and particular id in address bar matches the id in db

    $id = $_GET['id'];
    $userId = $_SESSION['userId'];
    $stmt = "SELECT * FROM blog_post WHERE id='$id'";
    $query = mysqli_query($conn, $stmt);
    $result = mysqli_fetch_assoc($query);
    $userid = $result['userid'];
    #Address bar userid
    $addressId = $_GET['userid'];
    if($addressId == $userId && $_GET['id'] == $result['id']){
        header("location: postform.php?id=$id&userid=$userId");
        die;
    }else{
        #redirect user to err page
        header("location: error.php?err=Sorry, Cannot get the page you are looking for hey");
        die;
    }
}
else{
    header("location: admin.php");
}

?>