<?php 
require("../config/db.php");

if(isset($_GET['id']) && isset($_GET['userid']) || isset($_SESSION['userId']) && isset($_SESSION['adminRole'])){
    session_start();

    $postid = $_GET['id'];
    #stmt to del post from db
    $stmt = "DELETE FROM blog_post WHERE id='$postid'";
    if (mysqli_query($conn, $stmt)) {
       if(isset($_SESSION['adminRole'])){
            $msg = "Successfully Deleted your post";
            header("location: admin.php?msg=$msg");
            die;
       }else{
           echo "";
           die;
       }
    }
}
else{
    header("location: error.php?err=The page you're looking for isnt available.");
}














?>