
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Dashoard Page" />
    <title>Dashboard</title>

    <!-- icon -->
    <link rel="icon" href="../img/Logo/LOGO.png" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
    />
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <!-- css -->
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- <link rel="stylesheet" href="sum/summernote.css"> -->

    <!-- javascript -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="./dashboard/inc/ckeditor/ckeditor.js"></script>
    <link href="../ckeditor/plugins/codesnippet/lib/highlight/styles/atelier-dune.dark.css" rel="stylesheet">
    <script src="../ckeditor/plugins/codesnippet/lib/highlight/highlight.pack.js"></script>
    <script src="../ckeditor/plugins/embedsemantic/plugin.js"></script>
    <script src="js/highlight.min.js"></script>

    <!-- <script src="sum/summernote.min.js"></script> -->
  </head>
  <body>
    



