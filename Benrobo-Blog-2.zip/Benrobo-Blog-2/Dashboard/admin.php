<?php 
require_once("../config/db.php");
// require_once("inc/head.php");
require_once("head.php");

session_start();

if (isset($_SESSION['userId']) && isset($_SESSION['adminRole'])) {
    // display statistic
    $userid = $_SESSION['userId'];
    $stmt = "SELECT * FROM user_auth";
    $queryResentUser = mysqli_query($conn, $stmt);
    // $resultFromUsers = mysqli_fetch_assoc($queryResentUser);
    // print_r($resultFromUsers);
} else {
    header("location: ../index.php");
}




?>
    <nav class="navbar navbar-expand-lg">
      <span class="navbar-brand">
        <img src="../img/Logo/LOGO.png" alt="LOGO" />
      </span>
      <button class="burger btn btn-default" type="button">
        <i class="fa fa-bars" aria-hidden="true"></i>
      </button>
      <div class="register-cont ml-5 mb-3">
        <div class="user ml-5 m-2 p-1">
        <?php 
          if(isset($_SESSION['userId']) && isset($_SESSION['adminRole'])){
            $userid = $_SESSION['userId'];
            $stmt = "SELECT * FROM user_auth WHERE id='$userid'";
            $query = mysqli_query($conn, $stmt);
            $res = mysqli_fetch_assoc($query);
            echo "<a href='../about.php' style='text-decoration:none; color:#fff;'>";
            echo '<i class="fa fa-user fa-1x text-info"></i>
            <span class="username">'.$res['username'].'</span>';
            echo "</a>";
          } 
        ?>  
      </div>
      </div>
    </nav>
<!-- alert if item was uploaded succesfully or not -->
<?php 
    if(isset($_GET['msg'])){
        $msg = $_GET['msg'];
        echo "<div style='border-radius:0px;' class='alert alert-success alert-error'>".$msg."</div>";
        header("Refresh: 1, admin.php");
    }
    elseif(isset($_GET['err'])){
        $err = $_GET['err'];
        echo "<div style='border-radius:0px;' class='alert alert-danger alert-error'>".$err."</div>";
        header("Refresh: 1, admin.php");
    }
        else{
        echo "";
    } 
?>
<section class="sections">

    <!-- sidebar -->
    <div class="mysidebar">
        <ul class="navbar-nav ml-0 mr-auto">
            <li class="nav-item">
            <button class="btn btn-default text-white tablink" onclick="openTabs(event, 'admin-stat')"><i class="fa fa-signal"></i> <small>Statistic</small></button>
            </li>
            <li class="nav-item">
            <button class="btn btn-default text-white tablink" onclick="openTabs(event, 'articles')"><i class="fa fa-newspaper-o"></i> <small>Articles</small></button>
            </li>
            <li class="nav-item">
            <button class="btn btn-default text-white tablink" onclick="openTabs(event, 'usertables')"><i class="fa fa-user-circle p-1"></i><small>Reg Users</small></button>
            </li>
            <li class="nav-item">
                <a href="admin_bio.php?addBio=1">
                    <button class="btn btn-default text-white tablink"><i class="fa fa-user-circle-o p-1"></i><small>Update BIO</small></button>
                </a>
            </li>
            <li class="nav-item" >
                <button class="btn btn-default text-white tablink p-0"><i class="fa fa-list p-1"></i><a href="postform.php"><small>Add Posts</small></a></button>
            </li>
            <li class="nav-item" >
                <button class="btn btn-default text-white tablink p-0"><i class="fa fa-list p-1"></i><a href="sendmsg.php"><small>Send NL</small></a></button>
            </li>
            <li class="nav-item" >
                <button class="btn btn-default text-white tablink" onclick="openTabs(event, 'admin-newsletter')"><i class="fa fa-comment"></i> News-sub</button>
            </li>
            <div class="admin-out">
                <a href="../logout.php?id=<?php echo $userid;?>" class="btn m-1 btn-danger p-1">
                    <span class="fa fa-sign-out p-1 text-dark"></span>Logout
                </a>
            </div>
        </ul>
    </div>

    <!-- main cobntent -->
    <div class="main-content mb-4 p-5">
        <a href="../index.php" class="btn btn-secondary"><small>← Back To Homepage</small></a>
        <!-- statistics -->
        <p>Dashboard</p>
        <p><i>WELCOME BACK<i>:  <?php echo $res['username']; ?></p>
        <div class="admin-stat">
            <h4>Statistic</h4>
            <div class="admin-cont tabcontent" id='admin-stat'>
                <div class="empty"></div>
                <div class="box">
                    <i class="fa fa-newspaper-o"></i>
                    <br>
                    <h5>POSTS COUNT</h5>
                    <h2 class="post-count" id="post-count"></h2>
                </div>
                <div class="box">
                    <i class="fa fa-user"></i> 
                    <br>
                    <h5>USERS</h5>
                    <h2 class="user-count" id="users-count"></h2>
                </div>
                <div class="box">
                    <i class="fa fa-comment"></i> 
                    <br>
                    <h5>COMMENTS</h5>
                    <h2 class="comment-count" id="comment-count">4</h2>
                </div>
                <div class="box">
                    <i class="fa fa-envelope"></i> 
                    <br>
                    <h5>NL-Sucribers</h5>
                    <h2 class="newsletter-count" id="newsletter-count"></h2>
                </div>
                <div class="empty"></div>
            </div>
            <br>
            <div class="users tabcontent" id='usertables'>
                <div class="users-cont">
                    <div class="card table-responsive">
                        <div class="card-header">
                            <p>RESENT USERS</p>
                        </div>
                        <div class="card-body table-responsive table-borderless">
                            <table class="table table-striped table-hover table-dark">
                                <thead>
                                    <th><small>Username</small></th>
                                    <th><small>Profiles</small></th>
                                    <th><small>Logged-in</small></th>
                                    <th><small>Role</small></th>
                                    <th><small>Action</small></th>
                                </thead>
                                <tbody>
                                    <?php while($resultFromUsers = mysqli_fetch_assoc($queryResentUser)): ?>
                                    <tr>
                                        <td><small><?php echo $resultFromUsers['username']; ?></small></td>
                                        <td><small><a href="user_profile.php?id=<?php echo $resultFromUsers['id'];?>">Profile</a></small></td>
                                        <td class="active-user">
                                            <?php 
                                            if($resultFromUsers['isLogged_in'] == 1){
                                                echo "<small>on</small>";
                                            }else{
                                                echo "<small>off</small>";
                                            }
                                            
                                            ?>                
                                        </td>
                                        <td>
                                            <small>
                                                <?php 
                                                    echo $resultFromUsers['position'];
                                                ?> 
                                            </small>
                                        </td>
                                        <td>
                                            <?php if($resultFromUsers['position'] == "USER" || $resultFromUsers['position'] == "ADMIN"): ?>
                                                <small><a href="confirm_del.php?id=<?php echo $resultFromUsers['id']; ?>&userid=<?php echo $_SESSION['userId'];?>" class="text-danger">Del Acc</a></small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-info" id="setUserPositionBtn">Set Users Position</button>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="articles tabcontent" id='articles'>
                <div class="articles-cont">
                    <div class="card table-responsive">
                        <div class="card-header">
                            <p>Articles</p>
                        </div>
                        <div class="card-body table-responsive table-borderless">
                            <table class="table table-striped table-hover table-dark">
                                <thead>
                                    <th><small>Topic</small></th>
                                    <th><small>Role</small></th>
                                    <th><small>Preview</small></th>
                                    <th><small>Date</small></th>
                                    <th><small>Action</small></th>
                                </thead>
                                <tbody id="article-tablebody" class="p-0">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <br>
            <div class="admin-newsletter mt-2" id="admin-newsletter">
                <div class="newsletter-cont">
                    <div class="card table-responsive">
                        <div class="card-header">
                            <p>News Letter Suscribers
                            <?php 
                                $sql = "SELECT * FROM newsletter_tbl";
                                $query = mysqli_query($conn, $sql);
                                $count = mysqli_num_rows($query);
                                echo "<span class='badge badge-primary'>".$count."</span>";
                            ?>
                            </p>
                        </div>
                        <div class="card-body table-responsive table-borderless">
                            <table class="table table-striped table-hover table-dark">
                                <thead>
                                    <th><small>Name</small></th>
                                    <th><small>Email</small></th>
                                    <th><small>Date</small></th>
                                    <th><small>Action</small></th>
                                </thead>
                                <tbody id="newsletter-tablebody" class="p-0">
                                    <?php 
                                        if(isset($_SESSION['userId']) && isset($_SESSION['adminRole'])){
                                            $sql = "SELECT * FROM newsletter_tbl";
                                            $query = mysqli_query($conn, $sql);
                                            #loop through all suscribers
                                            while($res = mysqli_fetch_assoc($query)){
                                                $id = $res['id'];
                                                $email = $res['email'];
                                                $name = $res['username'];
                                                $date = strtotime($res['suscribe_at']);
                                                $fmtdate = getdate($date);
                                                // Array ( [seconds] => 23 [minutes] => 3 [hours] => 19 [mday] => 18 [wday] => 1 [mon] => 1 [year] => 2021 [yday] => 17 [weekday] => Monday [month] => January [0] => 1610993003 ) Array ( [seconds] => 4 [minutes] => 4 [hours] => 19 [mday] => 18 [wday] => 1 [mon] => 1 [year] => 2021 [yday] => 17 [weekday] => Monday [month] => January [0] => 1610993044 )
                                                $dayofwk = $fmtdate['weekday'];
                                                $mth = $fmtdate['month'];
                                                $day = $fmtdate['mday'];
                                                $yr = $fmtdate['year'];
                                                $time = $fmtdate['hours'].":".$fmtdate['minutes'];

                                                // new date
                                                $newdate = $dayofwk." , ".$mth." ".$day." ".$yr." / ".$time;

                                                echo "
                                                    <tr>
                                                        <td><small>".$name."</small></td>
                                                        <td><small>".$email."</small></td>
                                                        <td><small>".$newdate."</small></td>
                                                        <td><small><a href='newsletterDel.php?id=$id'>Del</a></small></td>
                                                    </tr>
                                                ";
                                            }
                                        }
                                                
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>   
    </div>
</section>

<div class="setusers-ovl">
    <div class="card users-cont">
        <div class="card-header">
            <h5>Set Users Position</h5>
            <br>
        </div>
        <div class="card-body" id="user-cont">
            <?php 
                if(isset($_SESSION['userId']) && isset($_SESSION['adminRole'])){
                    # List all users in db
                    $usersStmt = "SELECT * FROM user_auth";
                    $query = mysqli_query($conn, $usersStmt); 
                }
            ?>
            <form action="setRoles.php" method="post" class="form-group">
                <label>List of users & Positions</label>
                <select name="users" id="users_drpdw" class="users form-control">
                    <?php while($result = mysqli_fetch_assoc($query)):?>
                    <option value="<?php echo $result['username']; ?>"><?php echo $result['username']; ?> (<?php echo $result['position']; ?>)</option>
                    <?php endwhile; ?>
                </select>
                <label>List Position</label>
                <select name="position"  class="position form-control">
                    <option value="ADMIN">ADMIN</option>
                    <option value="USER">USER</option>
                </select>
                <div class="clearfix mt-3">
                    <div class="float-left">
                       <input type="submit" name="setpositionbtn" value="Save Record" class="btn btn-info">
                    </div>
                    <div class="float-right">
                        <button class="btn btn-danger" id="canceluserbtn">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
    <script src="js/index.js"></script>
    <script>
        function openSidebar(){
            let burger = document.querySelector('.burger');
            let sidebar = document.querySelector('.mysidebar');
            isOpen = false;
            burger.addEventListener('click', ()=>{
            if ((isOpen == false)) {
                sidebar.style.width = "0px";
                isOpen = true;
            } else {
                sidebar.style.width = "150px";
                isOpen = false;
            }
            })
        }
        openSidebar();
    </script>
   </body>
</html>