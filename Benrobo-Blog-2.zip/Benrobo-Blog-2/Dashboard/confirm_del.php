<?php 
require_once("../config/db.php");
session_start();

if(isset($_SESSION['adminRole']) && isset($_GET['id'])){
    $id = $_GET['id'];

    $sql  ="SELECT * FROM user_auth WHERE id=$id";
    $query2 = mysqli_query($conn, $sql);

    if(isset($_SESSION['adminRole']) && isset($_GET['id']) && isset($_GET['userid'])){
        $id = $_GET['id'];
        $userid = $_GET['userid'];
        # fetch data from db
        $sql  ="SELECT * FROM user_auth WHERE id=$id";
        $query = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($query);
    }
    else{
        header("location: ../index.php");
        die;
    }
}else{
    header("location: error.php?err=Ooops Page Not Found");
    die;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confrim Box</title>
    <link rel="icon" href="../img/Logo/LOGO.png" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <style>
        body{
            background:#000;
            color:#fff;
        }
        .overlay{
            width:100%;
            height:100vh;
            position:fixed;
            top:0px;
            left:0px;
            display:flex;
            align-items:center;
            justify-content:center;
            background:rgba(0,0,0,.7);
            color:#fff;
        }
        .card{
            width:350px;
            height:auto;
            text-align:center;
            color:#000;
        }
        h3{
            font-family:Poppins;
            font-weight:300;
            font-size:20px;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="comfirm-cont card">
            <div class="card-body">
                <h3>You are just about to <b style="color:red;">Terminate</b> <strong><?php echo $data['username']; ?></strong> account, Which might lead to loss of data on your site.
                <h4>Are you sure?</h4></h3>
            </div>
            <div class="card-footer">
                <div class="clear-fix">
                    <div class="float-left">
                        <a href="userdel.php?id=<?php echo $_GET['id']; ?>&userid=<?php echo $_GET['userid']; ?>" class="btn btn-success">Proceed</a>
                    </div>
                    <di class="float-right">
                        <a href="admin.php" class="btn btn-danger">Cancel</a>
                    </di>
                </div>
            </div>
        </div>
    </div>
</body>
</html>