<?php 
require_once("../config/db.php");
require_once("head.php");

session_start();

if (isset($_SESSION['adminRole']) && isset($_SESSION['userId']) && isset($_GET['addBio'])) {
   if(isset($_POST['submit'])){
       $content = $_POST['body'];
       $userid = $_SESSION['userId'];

       if(empty($content)){
        echo "<script>alert('Fields cannot be empty')</script>";
        header("Refresh:1, admin_bio.php");
       }else{
            $query = mysqli_query($conn, "INSERT INTO admin_bio(userid, contents) VALUES('$userid','$content')");

            if($query){
                echo "<script>alert('Successfully Added Bio')</script>";
            }else{
                echo "Something went wrong".mysqli_error($conn);
            }
       }
    }
   
}
elseif(isset($_SESSION['userId']) && isset($_SESSION['adminRole']) && isset($_GET['type'])){
    $userid = $_SESSION['userId'];
    $query = mysqli_query($conn, "SELECT * FROM admin_bio WHERE userid='$userid'");
    $res = mysqli_fetch_assoc($query);

    #update bio
    if(isset($_POST['submit'])){
        $content = $_POST['editbody'];
        if(empty($content)){
            echo "<script>alert('Fields cannot be empty')</script>";
            header("Refresh:1, admin_bio.php?type=edit");
        }else{
            $query = mysqli_query($conn, "UPDATE admin_bio SET contents='$content' WHERE userid='$userid'");

            if($query){
                echo "<script>alert('Successfully updated bio')</script>";
                header("Refresh:1, ../about.php");
            }else{
                echo "Something went wrong".mysqli_error($conn);
            }
        }
    }
}
else {
    header("location: ../index.php");
}

?>
<div class="admin-post tabcontent mt-2" id="admin-post">
    <div class="post-cont p-2">
        <p>Add Bio</p>
        <div class="clear-fix p-4" style="">
            <div class="float-left">
                <a href="../index.php" class="text-white p-0">← Homepage</a>
            </div>
            <div class="float-right">
                <a href="admin.php" class="text-white p-0">Dashboard →</a>
            </div>
        </div>
        <br>
        <div class="card">
            <div class="card-header">Add Bio</div>
        <!-- post form -->
            <?php if(isset($_SESSION['userId']) && isset($_SESSION['adminRole']) && isset($_GET['addBio'])):?>
            <form action="#" method="POST" class="form-group">
                <div class="card-body">
                        <!-- texteditor -->
                        <textarea name="body" id="editor" class="form-control"></textarea>
                </div>
                <div class="card-footer">
                    <input type="submit" id="sendbtn" name='submit' class="btn btn-info btn-block">
                </div>
            </form>
            <?php endif;?>
            <?php if(isset($_SESSION['userId']) && isset($_SESSION['adminRole']) && isset($_GET['type'])):?>
                <form method="POST" class="form-group">
                    <div class="card-body">
                            <!-- texteditor -->
                            <textarea name="editbody" id="editor" class="form-control"><?php echo $cont = $res['contents']; ?></textarea>
                    </div>
                    <div class="card-footer">
                        <input type="submit" id="sendbtn" name='submit' class="btn btn-info btn-block">
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src='js/index.js'></script>
