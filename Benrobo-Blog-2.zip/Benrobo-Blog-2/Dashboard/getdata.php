<?php 
require("../config/db.php");

session_start();

if(isset($_POST['loadDataFromDb']) && isset($_COOKIE['email']) && isset($_COOKIE['newpwd']) && isset($_SESSION['userId']) && isset($_SESSION['adminRole'])){
    $userid = $_SESSION['userId'];
    // $userid = $_SESSION['userId'];
    
    #stmt-(statement to fetch data from blog_post table)
    $stmt = "SELECT * FROM blog_post ORDER BY id ASC";
    $query = mysqli_query($conn, $stmt);
 
    #loop through data from server
    while($data = mysqli_fetch_assoc($query)){
        # extract some data from db
        $useridfromdb = $data['userid'];
        $postid = $data['id'];
        $title = str_replace(' ','-' ,$data['post_title']);
        $position = $data['position'];
        $dbdate = $data['post_date'];
        $date = strtotime($dbdate);
        $newdate = getdate(date("$date"));
        $weday = $newdate['weekday'];
        $mon = $newdate['month'];
        $day = $newdate['wday'];
        $yr = $newdate['year'];
        $hr = $newdate['hours'];
        $min = $newdate['minutes'];
        $newdatestring = $weday.", ".$mon." ".$day." ".$yr." "." | ".$hr.":".$min;
        #send data to front-end
        if(isset($_SESSION['adminRole'])){
            echo '<tr class="p-0">
            <td>'.$title.'</td>
            <td>'.$position.'</td>
            <td><a href="../posts.php?postid='.$postid.'&title='.$title.'" target="_blank">link</a></td>
            <td><small>'.$newdatestring.'</small></td>
            <td class="action-cont">
            
            <a href="articleEdit.php?id='.$postid.'&userid='.$userid.'" id="delbtn" class="text m-1 text-primary">Edit</a>

            <a href="articleDel.php?id='.$postid.'&userid='.$userid.'" id="delbtn"  class="text m-1 text-danger">Del</a>
            
            </td>
            </tr>';
        }
    }
}
// load posts count in db
else if(isset($_POST["loadPostDataFromDb"])){
    #stmt-(statement to fetch data from blog_post table)
    $stmt = "SELECT * FROM blog_post";
    $query = mysqli_query($conn, $stmt);
    $count = mysqli_num_rows($query);
    echo $count;
}

// load users count in db
else if(isset($_POST["loadUsersDataFromDb"])){
    #stmt-(statement to fetch data from users table table)
    $stmt = "SELECT * FROM user_auth";
    $query = mysqli_query($conn, $stmt);
    $count = mysqli_num_rows($query);
    echo $count;
}

// load comment count in db
else if(isset($_POST["loadCommentDataFromDb"])){
    
    #stmt-(statement to fetch data from likes table table)
    $stmt = "SELECT * FROM comments";
    $query = mysqli_query($conn, $stmt);
    $count = mysqli_num_rows($query);
    echo $count;
}
// load newsleter suscribers count
else if(isset($_SESSION['adminRole']) && isset($_SESSION['userId']) && isset($_POST['newsletter'])){
    #stmt-(statement to fetch data from newsletter table table)
    $stmt = "SELECT * FROM newsletter_tbl";
    $query = mysqli_query($conn, $stmt);
    $count = mysqli_num_rows($query);
    echo $count;

}
else{  
    header("location: error.php?err=Page you are looking for isnt available");
    die;
}

// header("location: error.php?err=Page you are looking for isnt available");

?>