<?php 
require_once("../config/db.php");

session_start();

if (isset($_SESSION['adminRole']) && isset($_SESSION['userId']) &&$_GET['type'] = "delete") {

    $query = mysqli_query($conn, "DELETE FROM admin_bio WHERE userid='$userid'");

    if($query){
        echo "<script>alert('Successfully Deleted Bio')</script>";
        header("Refresh:1, ../about.php");
        die;
    }else{
        echo "Something went wrong".mysqli_error($conn);
        die;
    }
   
}else{
    header("location: ../index.php");
    die;
}

?>