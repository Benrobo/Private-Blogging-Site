<?php require("includes/head.php");?>
<?php require("config/db.php");
  session_start();

?>
<?php require("includes/nav.php");?>

<header class="about-header">
    <div class="overlay">
        <p><a href="index.php" class='text-white m-2'>← Back</a></p>
    <div class="ovl-cont">
        <h1 class='display-4 abouts-title text-center'>About Me</h1>
        <br />  
    </div>
    </div>
</header>

<section class="about-section">
    <div class="content">
        
        <div class="info">
            <div class="about-info">
                <div class="img mt-4">
                </div>
                <div class="footer-area">
                    <div class="info-section">
                        <div class="cont">
                            <b><p>Alumona Benaiah</p></b>

                            <div class="follow-btn">
                                <div class="clear-fix">
                                    <div class="float-left">
                                        <a href="https://benrobo.000webhostapp.com" class="btn btn-info"><small>Portfolio</small></a>
                                    </div>
                                    <div class="float-right">
                                        <a href="contact.php" class="btn btn-info">
                                            <small>Contact Me</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="stacks">
                        <p class="ml-2">Tech Stacks</p>
                        <div class="stack-cont">
                            <div class="html box"></div>
                            <div class="js box"></div>
                            <div class="jq box"></div>
                            <div class="php box"></div>
                            <div class="react box"></div>
                            <div class="node box"></div>
                            <div class="boot box"></div>
                            <div class="py box"></div>
                        </div>
                    </div>
                    <div class="socials">
                        <a href="https://www.facebook.com/benaiah.alumona.5" target="_blank"><span class="fa fa-facebook-official f"></span></a>

                        <a href="https://www.youtube.com/channel/UCVzQyQe-OxsBpQY1jA2xo3w" target="_blank"><span class="fa fa-youtube-play y"></span></a>

                        <a href="https://github.com/Benrobo/" target="_blank"><span class="fa fa-github g"></span></a>
                        
                        <a href="https://www.instagram.com/_benrobo/" target="_blank"><span class="fa fa-instagram i"></span></a>
                        
                        <a href="https://www.twitter.com/AlumonaBenaiah/" target="_blank"><span class="fa fa-twitter"></span></a>
                    </div>
                    <?php if(isset($_SESSION['adminRole']) && isset($_SESSION['userId'])){?>
                        <div class="admin_edit p-2 mb-3">
                            <div class="clear-fix">
                                <div class="float-left">
                                    <a href="dashboard/admin_bio.php?type=edit" class="btn btn-info"><small>Edit</small></a>
                                </div>
                                <div class="float-right">
                                    <a href="dashboard/admin_bio_del.php?type=delete" class="btn btn-danger"><small>Delete</small></a>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="main">
             <?php 
                $query = mysqli_query($conn, "SELECT * FROM admin_bio");
                $data = mysqli_fetch_assoc($query);
            ?>
            <div class="body mt-5">
                <?php echo $data['contents'];?>
            </div>
        </div>
    </div>
</section>


<?php require("includes/footer.php")?>