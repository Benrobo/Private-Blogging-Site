<!-- our database file must be include ineach page when created -->
<?php require('config/db.php'); ?>

<?php require('includes/head.php'); ?>

<!-- navbar contents -->
<?php require('includes/nav.php'); ?>

<!-- form to addpost -->

<div class="form-cont">
    <form action="addval.php" class="form" method='post'>
        <h3>Add Post</h3>
        <?php if(isset($_GET['err'])): ?>
            <p style='color:red;'><?php echo $_GET['err']; ?></p>
        <?php endif; ?>
        <label>Title</label>
        <input type="text" name='title' class="inp">

        <label>Sub_title</label>
        <input type="text" name='sub_title' class="inp">

        <label>Author</label>
        <input type="text" name='author' class="inp">

        <label>Contents</label>
        <textarea name="body" id="" cols="30" rows="13"></textarea>

        <input type="submit" name='submit' value='Add Post' class="btn">
    </form>
</div>