<?php 
require("config/db.php");

require("notify_func.php");
session_start();

// insert commebnts
if(isset($_POST['body']) && isset($_POST['postid']) && isset($_POST['userid']) && isset($_POST['posttitle']) && isset($_SESSION['userId'])){
    $postid = $_POST['postid'];
    $userid = $_POST['userid'];
    $post_title = $_POST['posttitle'];
    $body = mysqli_real_escape_string($conn, htmlspecialchars($_POST['body']));
    $blg_stmt = mysqli_query($conn, "SELECT * FROM blog_post WHERE id='$postid' AND userid='$userid'");
    $blog_data = mysqli_fetch_assoc($blg_stmt);
    $blog_comments = $blog_data['comments'];
    $newcomm_count = 1;
    #update comment column in blog-post to 1

    $stmt = mysqli_query($conn, "UPDATE blog_post SET comments='$blog_comments' WHERE id='$postid' AND userid='$userid'");
    // Fatal error: Uncaught Error: Call to undefined function getTotalCommentCount() in C:\xampp\htdocs\Benrobo-Blog-2\comments.php:28 Stack trace: #0 {main} thrown in C:\xampp\htdocs\Benrobo-Blog-2\comments.php on line 28
    if($stmt){
        // insert data in comments
        $query = mysqli_query($conn, "INSERT INTO comments(postid, userid,post_title, comments) VALUES('$postid','$userid','$post_title','$body')");
        if($query){
            #grab blog_post comment column value
            
            echo "Comment added";
            
            getTotalCommentCount($conn);
        }else{
            echo "Something went wrong, pls try later";
            die;
        }
    }else{
        echo "error".mysqli_error($conn);
    }
}
else if(isset($_POST['count']) && isset($_POST['postid'])){
    $post_id = $_POST['postid'];
    $stmt2 = mysqli_query($conn, "SELECT * FROM comments WHERE postid='$post_id'");
    $count = mysqli_num_rows($stmt2);
    echo $count;
    die;
}
else{
    header("location: dashboard/error.php?err=Sorry cannot get the page you are looking for");
    die;
}

?>
